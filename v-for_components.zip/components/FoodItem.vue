<template>
  <div>
      <h2>{{ foodName }}</h2>
  </div>
</template>

<script>
export default {
  props: ['foodName']
};
</script>

<style></style>